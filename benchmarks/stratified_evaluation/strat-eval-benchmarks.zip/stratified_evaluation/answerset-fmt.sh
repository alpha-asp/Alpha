#!/bin/bash

FMT_CLINGO="sed -ne '/Answer/,/SATISFIABLE/{/Answer/b;/SATISFIABLE/b;p}' | sed -e 's/) /)\n/g' | sort"
FMT_ALPHA="sed -ne '/Answer/,/SATISFIABLE/{/Answer/b;/SATISFIABLE/b;p}' | sed -e 's/{ //g' | sed -e 's/}//g' | sed -e 's/), /)\n/g' | sed -e 's/, /,/g' | sort"


if [ $1 = "clingo" ]
then
	cat $2 | eval ${FMT_CLINGO}
elif [ $1 = "alpha" ]
then
	cat $2 | eval ${FMT_ALPHA}
fi
