#!/bin/bash

for i in {1..10}
do
	make all
	mv test-results test-results-${i}
done
